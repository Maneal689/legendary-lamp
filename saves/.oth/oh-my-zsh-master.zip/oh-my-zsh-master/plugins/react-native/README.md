# React Native 

**Maintainer:** [BilalBudhani](https://github.com/BilalBudhani)

### List of Aliases

Alias | React Native command
------|---------------------
**rnand** | *react-native run-android*
**rnios** | *react-native run-ios*
**rnios4s** | *react-native run-ios --simulator "iPhone 4s"*
**rnios5** | *react-native run-ios --simulator "iPhone 5"*
**rnios5s** | *react-native run-ios --simulator "iPhone 5s"*

